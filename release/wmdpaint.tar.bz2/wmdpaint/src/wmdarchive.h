/* wmdarchive.h -- layered wmdpaint archive writer.
 *
 * A .wmd is an ordinary POSIX ustar archive.  A .wmd.bz2 is that same byte
 * stream compressed by the external bzip2 program.  Pixel entries remain
 * standard farbfeld or 1fpirate files; this container does not alter either
 * image format.
 */
#ifndef WMDARCHIVE_H
#define WMDARCHIVE_H

#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/wait.h>

static int
wmd_write_all(FILE *f, const void *buf, size_t len)
{
	return len == 0 || fwrite(buf, 1, len, f) == len;
}

static int
wmd_octal(unsigned char *dst, size_t width, unsigned long value)
{
	size_t i;
	if (width < 2) return 0;
	memset(dst, '0', width);
	dst[width - 1] = '\0';
	for (i = width - 1; i > 0 && value; ) {
		dst[--i] = (unsigned char)('0' + value % 8);
		value /= 8;
	}
	return value == 0;
}

static int
wmd_tar_header(FILE *f, const char *name, size_t size)
{
	unsigned char h[512];
	unsigned int sum = 0;
	size_t i, n = strlen(name);
	if (n == 0 || n >= 100) return 0;
	memset(h, 0, sizeof h);
	memcpy(h, name, n);
	if (!wmd_octal(h + 100, 8, 0644) || !wmd_octal(h + 108, 8, 0) ||
	    !wmd_octal(h + 116, 8, 0) ||
	    !wmd_octal(h + 124, 12, (unsigned long)size) ||
	    !wmd_octal(h + 136, 12, (unsigned long)time(NULL))) return 0;
	memset(h + 148, ' ', 8);
	h[156] = '0';
	memcpy(h + 257, "ustar", 5);
	memcpy(h + 263, "00", 2);
	memcpy(h + 265, "wmdpaint", 8);
	memcpy(h + 297, "wmdpaint", 8);
	for (i = 0; i < sizeof h; i++) sum += h[i];
	snprintf((char *)h + 148, 7, "%06o", sum);
	h[154] = '\0'; h[155] = ' ';
	return wmd_write_all(f, h, sizeof h);
}

static int
wmd_tar_pad(FILE *f, size_t size)
{
	static const unsigned char zero[512] = {0};
	size_t pad = (512 - size % 512) % 512;
	return wmd_write_all(f, zero, pad);
}

static int
wmd_layer_is_1fp(const Layer *l)
{
	size_t i, n = (size_t)l->w * l->h;
	for (i = 0; i < n; i++) {
		const uint16_t *p = l->px + i * 4;
		if (p[3] != 0xffff || p[0] != p[1] || p[1] != p[2] ||
		    (p[0] != 0 && p[0] != 0xffff)) return 0;
	}
	return 1;
}

static int
wmd_tar_ff(FILE *f, const char *name, uint32_t w, uint32_t h,
	   const uint16_t *px)
{
	unsigned char head[16], out[8192];
	uint32_t be;
	size_t i, n = (size_t)w * h * 4, at = 0;
	if (n > (SIZE_MAX - 16) / 2 || !wmd_tar_header(f, name, 16 + n * 2))
		return 0;
	memcpy(head, "farbfeld", 8);
	be = htonl(w); memcpy(head + 8, &be, 4);
	be = htonl(h); memcpy(head + 12, &be, 4);
	if (!wmd_write_all(f, head, sizeof head)) return 0;
	for (i = 0; i < n; i++) {
		out[at++] = (unsigned char)(px[i] >> 8);
		out[at++] = (unsigned char)px[i];
		if (at == sizeof out) {
			if (!wmd_write_all(f, out, at)) return 0;
			at = 0;
		}
	}
	return wmd_write_all(f, out, at) && wmd_tar_pad(f, 16 + n * 2);
}

static int
wmd_tar_1fp(FILE *f, const char *name, const Layer *l)
{
	unsigned char head[16], row[8192];
	uint32_t be, y, x, rb = (l->w + 7) / 8;
	size_t size = 16 + (size_t)rb * l->h;
	if (rb > sizeof row || !wmd_tar_header(f, name, size)) return 0;
	memcpy(head, "1fpirate", 8);
	be = htonl(l->w); memcpy(head + 8, &be, 4);
	be = htonl(l->h); memcpy(head + 12, &be, 4);
	if (!wmd_write_all(f, head, sizeof head)) return 0;
	for (y = 0; y < l->h; y++) {
		memset(row, 0, rb);
		for (x = 0; x < l->w; x++)
			if (l->px[((size_t)y * l->w + x) * 4] == 0xffff)
				row[x / 8] |= (unsigned char)(1u << (7 - x % 8));
		if (!wmd_write_all(f, row, rb)) return 0;
	}
	return wmd_tar_pad(f, size);
}

static void
wmd_safe_name(char *dst, size_t cap, const char *src)
{
	size_t i = 0;
	while (*src && i + 1 < cap) {
		unsigned char c = (unsigned char)*src++;
		dst[i++] = (c < 32 || c == 127) ? ' ' : (char)c;
	}
	dst[i] = '\0';
}

static int
wmd_write_tar(const char *path, const FFImage *canvas, Layer **layers,
	      int nlayers, int active_layer)
{
	FILE *f;
	char manifest[16384], safe[128], entry[100];
	size_t used = 0;
	int i, ok = 0;
	static const unsigned char end[1024] = {0};
	f = fopen(path, "wb");
	if (!f) return 0;
	used += (size_t)snprintf(manifest + used, sizeof manifest - used,
		"wmdpaint 1\nwidth %u\nheight %u\nactive %d\nlayers %d\n\n",
		canvas->w, canvas->h, active_layer, nlayers);
	for (i = 0; i < nlayers; i++) {
		int mono = wmd_layer_is_1fp(layers[i]);
		wmd_safe_name(safe, sizeof safe, layers[i]->name);
		snprintf(entry, sizeof entry, "layers/%03d.%s", i,
		         mono ? "1fpirate" : "ff");
		if (used >= sizeof manifest) goto done;
		used += (size_t)snprintf(manifest + used, sizeof manifest - used,
			"layer %s\nname %s\nx %d\ny %d\nvisible %d\nopacity %.9g\n\n",
			entry, safe, layers[i]->x, layers[i]->y,
			layers[i]->visible, (double)layers[i]->opacity);
	}
	if (used >= sizeof manifest || !wmd_tar_header(f, "manifest", used) ||
	    !wmd_write_all(f, manifest, used) || !wmd_tar_pad(f, used)) goto done;
	for (i = 0; i < nlayers; i++) {
		int mono = wmd_layer_is_1fp(layers[i]);
		snprintf(entry, sizeof entry, "layers/%03d.%s", i,
		         mono ? "1fpirate" : "ff");
		if (mono) {
			if (!wmd_tar_1fp(f, entry, layers[i])) goto done;
		} else if (!wmd_tar_ff(f, entry, layers[i]->w, layers[i]->h,
		                       layers[i]->px)) goto done;
	}
	if (!wmd_tar_ff(f, "merged.ff", canvas->w, canvas->h, canvas->px) ||
	    !wmd_write_all(f, end, sizeof end)) goto done;
	ok = 1;
done:
	if (fclose(f) != 0) ok = 0;
	if (!ok) unlink(path);
	return ok;
}

static int
wmd_find_bzip2(char *out, size_t cap)
{
	const char *path = getenv("PATH"), *p;
	char dir[4096];
	if (!path) return 0;
	while (*path) {
		p = strchr(path, ':');
		if (!p) p = path + strlen(path);
		if ((size_t)(p - path) < sizeof dir) {
			size_t n = (size_t)(p - path);
			if (n) memcpy(dir, path, n); else { dir[0] = '.'; n = 1; }
			dir[n] = '\0';
			if (snprintf(out, cap, "%s/bzip2", dir) < (int)cap &&
			    access(out, X_OK) == 0) return 1;
		}
		path = *p ? p + 1 : p;
	}
	return 0;
}

/* Return 1 for compressed success, 2 for uncompressed fallback, 0 on error. */
static int
wmd_archive_save(const char *requested, const FFImage *canvas, Layer **layers,
	         int nlayers, int active_layer, char *actual, size_t actual_cap)
{
	char final[4096], tarpath[4096], tmptar[4096], tmpbz[4096], bz[4096];
	int have_bz, fd, outfd, status;
	pid_t pid;
	size_t len;
	if (!requested || !*requested || !canvas || nlayers < 1) return 0;
	snprintf(final, sizeof final, "%s", requested);
	len = strlen(final);
	if (len < 8 || strcmp(final + len - 8, ".wmd.bz2") != 0) {
		if (len >= 4 && strcmp(final + len - 4, ".wmd") == 0)
			snprintf(final + len, sizeof final - len, ".bz2");
		else
			snprintf(final + len, sizeof final - len, ".wmd.bz2");
	}
	have_bz = wmd_find_bzip2(bz, sizeof bz);
	if (have_bz) snprintf(tarpath, sizeof tarpath, "%.*s", (int)(strlen(final) - 4), final);
	else         snprintf(tarpath, sizeof tarpath, "%.*s", (int)(strlen(final) - 4), final);
	if (snprintf(tmptar, sizeof tmptar, "%s.tmp.XXXXXX", tarpath) >= (int)sizeof tmptar)
		return 0;
	fd = mkstemp(tmptar);
	if (fd < 0) return 0;
	close(fd);
	if (!wmd_write_tar(tmptar, canvas, layers, nlayers, active_layer)) return 0;
	if (!have_bz) {
		if (rename(tmptar, tarpath) != 0) { unlink(tmptar); return 0; }
		snprintf(actual, actual_cap, "%s", tarpath);
		return 2;
	}
	if (snprintf(tmpbz, sizeof tmpbz, "%s.tmp.XXXXXX", final) >= (int)sizeof tmpbz) {
		unlink(tmptar); return 0;
	}
	outfd = mkstemp(tmpbz);
	if (outfd < 0) { unlink(tmptar); return 0; }
	pid = fork();
	if (pid == 0) {
		int infd = open(tmptar, O_RDONLY);
		if (infd < 0 || dup2(infd, STDIN_FILENO) < 0 ||
		    dup2(outfd, STDOUT_FILENO) < 0) _exit(126);
		close(infd); close(outfd);
		execl(bz, "bzip2", "-c", (char *)NULL);
		_exit(127);
	}
	close(outfd);
	if (pid < 0 || waitpid(pid, &status, 0) < 0 || !WIFEXITED(status) ||
	    WEXITSTATUS(status) != 0) {
		unlink(tmpbz);
		if (rename(tmptar, tarpath) != 0) { unlink(tmptar); return 0; }
		snprintf(actual, actual_cap, "%s", tarpath);
		return 2;
	}
	if (rename(tmpbz, final) != 0) {
		unlink(tmpbz); unlink(tmptar); return 0;
	}
	unlink(tmptar);
	snprintf(actual, actual_cap, "%s", final);
	return 1;
}

#endif /* WMDARCHIVE_H */
