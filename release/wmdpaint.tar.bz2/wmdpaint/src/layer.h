/*
 * Layer — a pixel buffer with a canvas-space origin.
 * Designed to be composited over an FFImage.
 * Pixel layout: RGBA uint16_t, native endian (same as FFImage.px).
 */
#ifndef LAYER_H
#define LAYER_H

#include <stdint.h>
#include <stdlib.h>
#include "farbfeld.h"

typedef struct {
	uint16_t *px;      /* RGBA 16-bit, same layout as FFImage */
	int       x, y;    /* top-left position in canvas image coords */
	uint32_t  w, h;
	char      name[32];
	int       visible;
	float     opacity; /* 0.0–1.0; multiplied against each pixel's alpha */
} Layer;

static Layer *
layer_new(uint32_t w, uint32_t h)
{
	Layer *l = malloc(sizeof *l);
	if (!l) return NULL;
	l->px = calloc((size_t)w * h * 4, sizeof(uint16_t));
	if (!l->px) { free(l); return NULL; }
	l->x = l->y = 0;
	l->w = w;
	l->h = h;
	l->name[0] = '\0';
	l->visible  = 1;
	l->opacity  = 1.0f;
	return l;
}

static void
layer_free(Layer *l)
{
	if (l) { free(l->px); free(l); }
}

/*
 * Alpha-composite layer onto dst, clipped to canvas rect [cx0,cx1) x [cy0,cy1).
 * Layer pixels outside dst bounds or the clip rect are silently skipped.
 */
static void
layer_flatten_rect(const Layer *l, FFImage *dst,
                   int cx0, int cy0, int cx1, int cy1)
{
	int x, y, x0, y0, x1, y1, dx, dy;

	if (cx0 < 0) cx0 = 0;
	if (cy0 < 0) cy0 = 0;
	if (cx1 > (int)dst->w) cx1 = (int)dst->w;
	if (cy1 > (int)dst->h) cy1 = (int)dst->h;
	if (cx0 >= cx1 || cy0 >= cy1) return;

	/* Convert the destination clip into layer-local bounds first.  The old
	 * loops walked every pixel in a large layer even when a small dirty
	 * rectangle was being recomposited. */
	x0 = cx0 - l->x;
	y0 = cy0 - l->y;
	x1 = cx1 - l->x;
	y1 = cy1 - l->y;
	if (x0 < 0) x0 = 0;
	if (y0 < 0) y0 = 0;
	if (x1 > (int)l->w) x1 = (int)l->w;
	if (y1 > (int)l->h) y1 = (int)l->h;
	if (x0 >= x1 || y0 >= y1) return;

	for (y = y0; y < y1; y++) {
		dy = l->y + y;
		for (x = x0; x < x1; x++) {
			size_t   si, di;
			uint32_t sa, na, sr, sg, sb, dr, dg, db, da;
			dx = l->x + x;
			si = ((size_t)y  * l->w   + x)  * 4;
			di = ((size_t)dy * dst->w + dx) * 4;
			sa = (uint32_t)((float)l->px[si+3] * l->opacity);
			if (sa > 65535u) sa = 65535u;
			na = 65535u - sa;
			sr = l->px[si+0]; sg = l->px[si+1]; sb = l->px[si+2];
			dr = dst->px[di+0]; dg = dst->px[di+1];
			db = dst->px[di+2]; da = dst->px[di+3];
			dst->px[di+0] = (uint16_t)((sa * sr + na * dr) / 65535u);
			dst->px[di+1] = (uint16_t)((sa * sg + na * dg) / 65535u);
			dst->px[di+2] = (uint16_t)((sa * sb + na * db) / 65535u);
			dst->px[di+3] = (uint16_t)(sa + (na * da)      / 65535u);
		}
	}
}

static void
layer_flatten(const Layer *l, FFImage *dst)
{
	layer_flatten_rect(l, dst, 0, 0, (int)dst->w, (int)dst->h);
}

#endif /* LAYER_H */
